<?php
//This is a temporary file which has been automatically created by CrazyStat. You can delete it. Then CrazyStat will be slower the next time (and recreate the file).

$pos=47383;
$logdatei_name='../usr/logs/stat0.log';
$hits_user_tag=array (
  '27.9.2014' => 12,
  '28.9.2014' => 2,
);
$ips=array (
  '172.16.92.36*' => 784397,
);
$ips_dateien=array (
  '172.16.92.36*#/ninux/www/Ninux_rate_meter/grafici.php' => 784397,
  '172.16.92.36*#/ninux/www/Ninux_rate_meter/index.php' => 784397,
);
$ips_online=array (
);
$log_file_number=0;
$last_seen=array (
  '172.16.92.36*' => 1411914885,
);
$first_seen=array (
  1411914885 => 
  array (
    0 => '172.16.92.36*',
  ),
);
$save_timestamp=1411916092;
$usr_on_stamp=array (
);
$_SESSION["module_hit_data"]=array (
  'gesamt' => 218,
  'gesamt_ip' => 14,
  'diesen_monat' => 14,
  'letzten_monat' => 0,
  'user_online' => 0,
  'max' => 12,
  'durchschnitt' => 7,
  'visit_time_total' => 82080,
  'proUser' => 15.571428571429,
  'visit_time_avg' => 97.71,
  'max_tag' => '27.9.2014',
);
$_SESSION["module_hit_data_timestamps"]=array (
);
$_SESSION["module_weekday_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 12,
  7 => 0,
  0 => 2,
);
$_SESSION["module_weekday_data_timestamps"]=array (
  6 => 
  array (
    0 => 1411812070,
    1 => 1411813220,
    2 => 1411813916,
    3 => 1411814054,
    4 => 1411814098,
    5 => 1411816752,
    6 => 1411818994,
    7 => 1411833226,
    8 => 1411833276,
    9 => 1411836289,
    10 => 1411850350,
    11 => 1411851733,
  ),
  0 => 
  array (
    0 => 1411886755,
    1 => 1411914871,
  ),
);
$_SESSION["module_month_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 14,
  10 => 0,
  11 => 0,
  12 => 0,
);
$_SESSION["module_month_data_timestamps"]=array (
  9 => 
  array (
    0 => 1411812070,
    1 => 1411813220,
    2 => 1411813916,
    3 => 1411814054,
    4 => 1411814098,
    5 => 1411816752,
    6 => 1411818994,
    7 => 1411833226,
    8 => 1411833276,
    9 => 1411836289,
    10 => 1411850350,
    11 => 1411851733,
    12 => 1411886755,
    13 => 1411914871,
  ),
);
$_SESSION["module_day_data"]=array (
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 0,
  9 => 0,
  10 => 0,
  11 => 0,
  12 => 0,
  13 => 0,
  14 => 0,
  15 => 0,
  16 => 0,
  17 => 0,
  18 => 0,
  19 => 0,
  20 => 0,
  21 => 0,
  22 => 0,
  23 => 0,
  24 => 0,
  25 => 0,
  26 => 0,
  27 => 12,
  28 => 2,
  29 => 0,
  30 => 0,
  31 => 0,
);
$_SESSION["module_day_data_timestamps"]=array (
  27 => 
  array (
    0 => 1411812070,
    1 => 1411813220,
    2 => 1411813916,
    3 => 1411814054,
    4 => 1411814098,
    5 => 1411816752,
    6 => 1411818994,
    7 => 1411833226,
    8 => 1411833276,
    9 => 1411836289,
    10 => 1411850350,
    11 => 1411851733,
  ),
  28 => 
  array (
    0 => 1411886755,
    1 => 1411914871,
  ),
);
$_SESSION["module_hour_data"]=array (
  0 => 0,
  1 => 0,
  2 => 0,
  3 => 0,
  4 => 0,
  5 => 0,
  6 => 0,
  7 => 0,
  8 => 1,
  9 => 0,
  10 => 0,
  11 => 0,
  12 => 0,
  13 => 0,
  14 => 0,
  15 => 0,
  16 => 1,
  17 => 2,
  18 => 1,
  19 => 0,
  20 => 0,
  21 => 0,
  22 => 1,
  23 => 1,
);
$_SESSION["module_hour_data_timestamps"]=array (
  12 => 
  array (
  ),
  13 => 
  array (
  ),
  17 => 
  array (
    0 => 1411833226,
    1 => 1411833276,
  ),
  18 => 
  array (
    0 => 1411836289,
  ),
  22 => 
  array (
    0 => 1411850350,
  ),
  23 => 
  array (
    0 => 1411851733,
  ),
  8 => 
  array (
    0 => 1411886755,
  ),
  16 => 
  array (
    0 => 1411914871,
  ),
);
$_SESSION["module_browser_data"]=array (
  'Firefox 3.x' => 11,
  'Google Chrome' => 3,
);
$_SESSION["module_browser_data_timestamps"]=array (
  'Firefox 3.x' => 
  array (
    0 => 1411812070,
    1 => 1411813220,
    2 => 1411813916,
    3 => 1411814054,
    4 => 1411814098,
    5 => 1411833226,
    6 => 1411836289,
    7 => 1411850350,
    8 => 1411851733,
    9 => 1411886755,
    10 => 1411914871,
  ),
  'Google Chrome' => 
  array (
    0 => 1411816752,
    1 => 1411818994,
    2 => 1411833276,
  ),
);
$_SESSION["module_file_data"]=array (
  '/ninux/www/Ninux_rate_meter/' => 1,
  '/ninux/www/Ninux_rate_meter/registrazione.php' => 4,
  '/ninux/www/Ninux_rate_meter/grafici.php' => 8,
  '/ninux/www/Ninux_rate_meter/index.php' => 4,
  '/' => 2,
  '/elenco_nodi.php' => 2,
  '/grafici.php' => 2,
  '/ninux/www/Ninux_rate_meter/elenco_nodi.php' => 4,
  '/ninux/www/Ninux_rate_meter/grafici.php?' => 2,
);
$_SESSION["module_file_data_timestamps"]=array (
  '/ninux/www/Ninux_rate_meter/' => 
  array (
    0 => 1411812070,
  ),
  '/ninux/www/Ninux_rate_meter/registrazione.php' => 
  array (
    0 => 1411812492,
    1 => 1411850425,
    2 => 1411851733,
    3 => 1411886755,
  ),
  '/ninux/www/Ninux_rate_meter/grafici.php' => 
  array (
    0 => 1411812500,
    1 => 1411813916,
    2 => 1411816782,
    3 => 1411836289,
    4 => 1411850350,
    5 => 1411852313,
    6 => 1411886757,
    7 => 1411914871,
  ),
  '/ninux/www/Ninux_rate_meter/index.php' => 
  array (
    0 => 1411812666,
    1 => 1411850404,
    2 => 1411852331,
    3 => 1411914885,
  ),
  '/' => 
  array (
    0 => 1411813220,
    1 => 1411814054,
  ),
  '/elenco_nodi.php' => 
  array (
    0 => 1411813293,
    1 => 1411833226,
  ),
  '/grafici.php' => 
  array (
    0 => 1411814066,
    1 => 1411814098,
  ),
  '/ninux/www/Ninux_rate_meter/elenco_nodi.php' => 
  array (
    0 => 1411816752,
    1 => 1411833276,
    2 => 1411850411,
    3 => 1411851789,
  ),
  '/ninux/www/Ninux_rate_meter/grafici.php?' => 
  array (
    0 => 1411816762,
    1 => 1411818994,
  ),
);
$_SESSION["module_resolution_data"]=array (
  '1280 x 1024' => 8,
  '1920 x 1080' => 2,
  '?' => 1,
  '320 x 480' => 3,
);
$_SESSION["module_resolution_data_timestamps"]=array (
  '1280 x 1024' => 
  array (
    0 => 1411812070,
    1 => 1411813916,
    2 => 1411814098,
    3 => 1411836289,
    4 => 1411850350,
    5 => 1411851733,
    6 => 1411886755,
    7 => 1411914871,
  ),
  '1920 x 1080' => 
  array (
    0 => 1411813220,
    1 => 1411833226,
  ),
  '?' => 
  array (
    0 => 1411814054,
  ),
  '320 x 480' => 
  array (
    0 => 1411816752,
    1 => 1411818994,
    2 => 1411833276,
  ),
);
$_SESSION["module_colordepth_data"]=array (
  24 => 13,
);
$_SESSION["module_colordepth_data_timestamps"]=array (
  24 => 
  array (
    0 => 1411812070,
    1 => 1411813220,
    2 => 1411813916,
    3 => 1411814098,
    4 => 1411816752,
    5 => 1411818994,
    6 => 1411833226,
    7 => 1411833276,
    8 => 1411836289,
    9 => 1411850350,
    10 => 1411851733,
    11 => 1411886755,
    12 => 1411914871,
  ),
);
$_SESSION["module_system_data"]=array (
  'Linux' => 11,
  'Android' => 3,
);
$_SESSION["module_system_data_timestamps"]=array (
  'Linux' => 
  array (
    0 => 1411812070,
    1 => 1411813220,
    2 => 1411813916,
    3 => 1411814054,
    4 => 1411814098,
    5 => 1411833226,
    6 => 1411836289,
    7 => 1411850350,
    8 => 1411851733,
    9 => 1411886755,
    10 => 1411914871,
  ),
  'Android' => 
  array (
    0 => 1411816752,
    1 => 1411818994,
    2 => 1411833276,
  ),
);
$_SESSION["module_referer_data"]=array (
  'http://ml.ninux.org/pipermail/firenze/2014-September/004055.html' => 1,
  'http://172.16.1.9/ninux/www/Ninux_rate_meter/grafici.php' => 5,
  'http://10.150.28.11/grafici.php' => 1,
  'http://salvatorehost.no-ip.org/ninux/www/Ninux_rate_meter/elenco_nodi.php' => 1,
  'http://10.150.28.11/' => 1,
);
$_SESSION["module_referer_data_timestamps"]=array (
  'http://ml.ninux.org/pipermail/firenze/2014-September/004055.html' => 
  array (
    0 => 1411813220,
  ),
  'http://172.16.1.9/ninux/www/Ninux_rate_meter/grafici.php' => 
  array (
    0 => 1411813916,
    1 => 1411836289,
    2 => 1411850350,
    3 => 1411851733,
    4 => 1411914871,
  ),
  'http://10.150.28.11/grafici.php' => 
  array (
    0 => 1411814098,
  ),
  'http://salvatorehost.no-ip.org/ninux/www/Ninux_rate_meter/elenco_nodi.php' => 
  array (
    0 => 1411818994,
  ),
  'http://10.150.28.11/' => 
  array (
    0 => 1411833226,
  ),
);
$_SESSION["module_keyword_data"]=array (
);
$_SESSION["module_keyword_data_timestamps"]=array (
);
?>